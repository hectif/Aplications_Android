package com.example.ligthoff;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button[][] boutons;
    Modele monModele;
    TextView affichage;
    int coups;
    String nb;
    MediaPlayer son;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        coups =0;
        affichage=(TextView)findViewById(R.id.message);
        monModele = new Modele();
        boutons = new Button[4][4];
        GridLayout zoneBoutons = (GridLayout)findViewById(R.id.zoneBoutons);
        View.OnClickListener monEcouteur = new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                int ligne=-1;
                int colonne=-1;
                Button target =(Button)v;
                for(int i=0;i<4;i++){
                    for(int j=0;j<4;j++){
                        if(boutons[i][j]==target){
                            ligne=i;
                            colonne=j;
                        }
                    }
                }
                monModele.clic(ligne,colonne);
                coups++;
                nb= String.valueOf(coups);
                affichage.setText("Vous avez utilisé "+nb+" coups");
                son= MediaPlayer.create(MainActivity.this, R.raw.frappe);
                son.start();
                afficheJeu();
            }
        };
        int count=0;
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                boutons[i][j] = new Button(this);
                boutons[i][j].setOnClickListener(monEcouteur );
                zoneBoutons.addView(boutons[i][j],count);
                count++;
            }
        }
        Button commencer =(Button)findViewById(R.id.commencer);
        commencer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initJeu();
            }
        });
        initJeu();
    }

    void initJeu(){
        monModele.initGrille();
        affichage.setText("Nouvelle partie");
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                boutons[i][j].setEnabled(true);
            }
        }
        coups=0;
        afficheJeu();
    }

    void afficheJeu(){
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                if(monModele.grille[i][j]){
                    boutons[i][j].setBackgroundColor(Color.BLACK);
                }
                else{
                    boutons[i][j].setBackgroundColor(Color.WHITE);
                }
            }
        }
        if(monModele.fin())
            finjeu();
    }

    void finjeu(){
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                boutons[i][j].setEnabled(false);
            }
        }
        MediaPlayer sonend= MediaPlayer.create(MainActivity.this, R.raw.win);
        sonend.start();
        affichage.setText("Bravo vous avez gagné en "+nb+" coups");
    }
}
