package com.example.ligthoff;

import android.view.Display;

public class Modele {
    boolean[][] grille;
    int coups;

    Modele(){
        grille= new boolean[4][4];
        initGrille();
    }

    void initGrille(){
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                //grille[i][j]=true;
                grille[i][j]=Math.random()<0.5;
                /*double alea=Math.random();
                if(alea<0.5){
                    grille[i][j]=true;
                }
                else{
                    grille[i][j]=false;
                }équivalent à la ligne au dessus*/
            }
        }
        coups = 0;
    }

    void clic(int ligne,int colonne) {
        for (int i = 0;i< 4;i++) {
            grille[ligne][i] = !grille[ligne][i];
            grille[i][colonne] = !grille[i][colonne];
        }
        grille[ligne][colonne] = !grille[ligne][colonne];
    }

    boolean fin(){
        /*
        int cpt=0;
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                if(!grille[i][j]){
                    cpt++;
                }
            }
        }
        return (cpt==16);
         */
        boolean test=true;
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                if(grille[i][j]){
                    test=false;
                    i=4;
                    j=4;
                }
            }
        }
        return test;
    }
}
